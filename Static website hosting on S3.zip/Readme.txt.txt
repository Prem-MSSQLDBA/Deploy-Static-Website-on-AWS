cloudFront domain name URL 
https://d26pupf12qepc0.cloudfront.net/post.html

website-endpoint URL
http://my-2360527-bucket.s3-website-us-east-1.amazonaws.com 